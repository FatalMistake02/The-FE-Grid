
package net.mcreator.fegrid.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DiamondCircitItem extends Item {
	public DiamondCircitItem() {
		super(new Item.Properties().stacksTo(16).rarity(Rarity.COMMON));
	}
}
