
package net.mcreator.fegrid.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BauxiteDustItem extends Item {
	public BauxiteDustItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
