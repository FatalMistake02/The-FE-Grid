
package net.mcreator.fegrid.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class WireSpoolItem extends Item {
	public WireSpoolItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
