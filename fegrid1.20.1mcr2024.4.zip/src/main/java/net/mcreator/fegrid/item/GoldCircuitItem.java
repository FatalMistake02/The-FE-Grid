
package net.mcreator.fegrid.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GoldCircuitItem extends Item {
	public GoldCircuitItem() {
		super(new Item.Properties().stacksTo(16).rarity(Rarity.COMMON));
	}
}
