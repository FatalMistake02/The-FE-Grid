
package net.mcreator.fegrid.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SolarPanelCircitItem extends Item {
	public SolarPanelCircitItem() {
		super(new Item.Properties().stacksTo(16).rarity(Rarity.COMMON));
	}
}
