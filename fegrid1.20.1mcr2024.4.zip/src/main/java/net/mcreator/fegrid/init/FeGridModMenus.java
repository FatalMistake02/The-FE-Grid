
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fegrid.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.fegrid.world.inventory.SmelterGUIMenu;
import net.mcreator.fegrid.world.inventory.ExtruderGUIMenu;
import net.mcreator.fegrid.world.inventory.APGUIMenu;
import net.mcreator.fegrid.FeGridMod;

public class FeGridModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, FeGridMod.MODID);
	public static final RegistryObject<MenuType<ExtruderGUIMenu>> EXTRUDER_GUI = REGISTRY.register("extruder_gui", () -> IForgeMenuType.create(ExtruderGUIMenu::new));
	public static final RegistryObject<MenuType<APGUIMenu>> APGUI = REGISTRY.register("apgui", () -> IForgeMenuType.create(APGUIMenu::new));
	public static final RegistryObject<MenuType<SmelterGUIMenu>> SMELTER_GUI = REGISTRY.register("smelter_gui", () -> IForgeMenuType.create(SmelterGUIMenu::new));
}
