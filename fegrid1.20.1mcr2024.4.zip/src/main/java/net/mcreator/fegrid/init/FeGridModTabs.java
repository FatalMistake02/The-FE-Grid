
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fegrid.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.fegrid.FeGridMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class FeGridModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FeGridMod.MODID);
	public static final RegistryObject<CreativeModeTab> POWER_GRID = REGISTRY.register("power_grid",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fe_grid.power_grid")).icon(() -> new ItemStack(FeGridModBlocks.ENERGY_BLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FeGridModBlocks.ENERGY_BLOCK.get().asItem());
				tabData.accept(FeGridModBlocks.SOLAR_PANEL.get().asItem());
				tabData.accept(FeGridModBlocks.SOLAR_PANEL_ON_FRAME.get().asItem());
				tabData.accept(FeGridModBlocks.SOLAR_PANEL_FRAME.get().asItem());
				tabData.accept(FeGridModBlocks.SOLAR_PANEL_FRAME_WITH_POWER_CABLE.get().asItem());
				tabData.accept(FeGridModItems.SOLAR_PANEL_CIRCIT.get());
				tabData.accept(FeGridModItems.DIAMOND_CIRCIT.get());
				tabData.accept(FeGridModItems.IRON_WIRE.get());
				tabData.accept(FeGridModItems.ALUMINUM_SHEET.get());
				tabData.accept(FeGridModItems.CAPACITOR.get());
				tabData.accept(FeGridModBlocks.EXTRUDER.get().asItem());
				tabData.accept(FeGridModItems.WIRE_SPOOL.get());
				tabData.accept(FeGridModItems.GOLD_CIRCUIT.get());
				tabData.accept(FeGridModItems.IRON_CIRCUIT.get());
				tabData.accept(FeGridModBlocks.CABLE.get().asItem());
				tabData.accept(FeGridModItems.COPPER_WIRE.get());
				tabData.accept(FeGridModBlocks.HALF_A_MILLION_STORAGE_BLOCK.get().asItem());
				tabData.accept(FeGridModItems.ALUMINIUM_FRAME.get());
				tabData.accept(FeGridModBlocks.ALUMINIUM_PROCESSOR.get().asItem());
				tabData.accept(FeGridModItems.ALUMINA.get());
				tabData.accept(FeGridModBlocks.QUARTER_OF_A_MILLION_STORAGE_BLOCK.get().asItem());
				tabData.accept(FeGridModBlocks.ONE_MILLION_STORAGE_UNIT.get().asItem());
				tabData.accept(FeGridModItems.SOLAR_CELL.get());
				tabData.accept(FeGridModItems.SILICON_WAFER.get());
				tabData.accept(FeGridModItems.SILICON_NUGGET.get());
				tabData.accept(FeGridModItems.SILICON_INGOT.get());
				tabData.accept(FeGridModItems.CARBON.get());
				tabData.accept(FeGridModItems.BATTERY.get());
				tabData.accept(FeGridModItems.BATTERY_GROUP_I.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.OP_BLOCKS) {
			if (tabData.hasPermissions()) {
				tabData.accept(FeGridModBlocks.FE_TESTER.get().asItem());
			}
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(FeGridModItems.BAUXITE_DUST.get());
			tabData.accept(FeGridModItems.ALUMINIUM_INGOT.get());
			tabData.accept(FeGridModItems.LITHIUM_DUST.get());
			tabData.accept(FeGridModItems.LITHIUM_INGOT.get());
			tabData.accept(FeGridModItems.STEEL_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(FeGridModBlocks.BAUXITE_ORE.get().asItem());
			tabData.accept(FeGridModBlocks.BAUXITE_BLOCK.get().asItem());
			tabData.accept(FeGridModBlocks.ALUMINIUM_BLOCK.get().asItem());
			tabData.accept(FeGridModBlocks.LITHIUM_BLOCK.get().asItem());
			tabData.accept(FeGridModBlocks.STEEL_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(FeGridModBlocks.SILICA_SAND.get().asItem());
			tabData.accept(FeGridModBlocks.GRANITE.get().asItem());
		}
	}
}
