
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fegrid.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.fegrid.block.entity.SolarPanelOnFrameBlockEntity;
import net.mcreator.fegrid.block.entity.SolarPanelBlockEntity;
import net.mcreator.fegrid.block.entity.SmelterBlockEntity;
import net.mcreator.fegrid.block.entity.QuarterOfAMillionStorageBlockBlockEntity;
import net.mcreator.fegrid.block.entity.OneMillionStorageUnitBlockEntity;
import net.mcreator.fegrid.block.entity.HalfAMillionStorageBlockBlockEntity;
import net.mcreator.fegrid.block.entity.FETesterBlockEntity;
import net.mcreator.fegrid.block.entity.ExtruderBlockEntity;
import net.mcreator.fegrid.block.entity.EnergyBlockBlockEntity;
import net.mcreator.fegrid.block.entity.CableWestUpBlockEntity;
import net.mcreator.fegrid.block.entity.CableWestDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpSouthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpSouthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpNorthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpNorthSouthBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpNorthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpEastWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpDownWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpDownSouthBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpDownNorthBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpDownEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableUpBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthUpBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthNorthBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthEastWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableSouthBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthUpBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthSouthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthSouthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthEastWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableNorthBlockEntity;
import net.mcreator.fegrid.block.entity.CableEastWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableEastUpBlockEntity;
import net.mcreator.fegrid.block.entity.CableEastDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownSouthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownSouthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownNorthWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownNorthSouthBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownNorthEastBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownEastWestBlockEntity;
import net.mcreator.fegrid.block.entity.CableDownBlockEntity;
import net.mcreator.fegrid.block.entity.CableBlockEntity;
import net.mcreator.fegrid.block.entity.AluminiumProcessorBlockEntity;
import net.mcreator.fegrid.FeGridMod;

public class FeGridModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FeGridMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> ENERGY_BLOCK = register("energy_block", FeGridModBlocks.ENERGY_BLOCK, EnergyBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SOLAR_PANEL = register("solar_panel", FeGridModBlocks.SOLAR_PANEL, SolarPanelBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SOLAR_PANEL_ON_FRAME = register("solar_panel_on_frame", FeGridModBlocks.SOLAR_PANEL_ON_FRAME, SolarPanelOnFrameBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> FE_TESTER = register("fe_tester", FeGridModBlocks.FE_TESTER, FETesterBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EXTRUDER = register("extruder", FeGridModBlocks.EXTRUDER, ExtruderBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE = register("cable", FeGridModBlocks.CABLE, CableBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> HALF_A_MILLION_STORAGE_BLOCK = register("half_a_million_storage_block", FeGridModBlocks.HALF_A_MILLION_STORAGE_BLOCK, HalfAMillionStorageBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ALUMINIUM_PROCESSOR = register("aluminium_processor", FeGridModBlocks.ALUMINIUM_PROCESSOR, AluminiumProcessorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> QUARTER_OF_A_MILLION_STORAGE_BLOCK = register("quarter_of_a_million_storage_block", FeGridModBlocks.QUARTER_OF_A_MILLION_STORAGE_BLOCK, QuarterOfAMillionStorageBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> SMELTER = register("smelter", FeGridModBlocks.SMELTER, SmelterBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ONE_MILLION_STORAGE_UNIT = register("one_million_storage_unit", FeGridModBlocks.ONE_MILLION_STORAGE_UNIT, OneMillionStorageUnitBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH = register("cable_north", FeGridModBlocks.CABLE_NORTH, CableNorthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH = register("cable_south", FeGridModBlocks.CABLE_SOUTH, CableSouthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_EAST = register("cable_east", FeGridModBlocks.CABLE_EAST, CableEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_WEST = register("cable_west", FeGridModBlocks.CABLE_WEST, CableWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP = register("cable_up", FeGridModBlocks.CABLE_UP, CableUpBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN = register("cable_down", FeGridModBlocks.CABLE_DOWN, CableDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_EAST_WEST = register("cable_east_west", FeGridModBlocks.CABLE_EAST_WEST, CableEastWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_NORTH = register("cable_south_north", FeGridModBlocks.CABLE_SOUTH_NORTH, CableSouthNorthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_DOWN = register("cable_up_down", FeGridModBlocks.CABLE_UP_DOWN, CableUpDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_DOWN = register("cable_north_down", FeGridModBlocks.CABLE_NORTH_DOWN, CableNorthDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_UP = register("cable_north_up", FeGridModBlocks.CABLE_NORTH_UP, CableNorthUpBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_EAST = register("cable_north_east", FeGridModBlocks.CABLE_NORTH_EAST, CableNorthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_WEST = register("cable_north_west", FeGridModBlocks.CABLE_NORTH_WEST, CableNorthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_DOWN = register("cable_south_down", FeGridModBlocks.CABLE_SOUTH_DOWN, CableSouthDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_UP = register("cable_south_up", FeGridModBlocks.CABLE_SOUTH_UP, CableSouthUpBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_EAST = register("cable_south_east", FeGridModBlocks.CABLE_SOUTH_EAST, CableSouthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_WEST = register("cable_south_west", FeGridModBlocks.CABLE_SOUTH_WEST, CableSouthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_EAST_DOWN = register("cable_east_down", FeGridModBlocks.CABLE_EAST_DOWN, CableEastDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_EAST_UP = register("cable_east_up", FeGridModBlocks.CABLE_EAST_UP, CableEastUpBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_WEST_DOWN = register("cable_west_down", FeGridModBlocks.CABLE_WEST_DOWN, CableWestDownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_WEST_UP = register("cable_west_up", FeGridModBlocks.CABLE_WEST_UP, CableWestUpBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_DOWN_NORTH = register("cable_up_down_north", FeGridModBlocks.CABLE_UP_DOWN_NORTH, CableUpDownNorthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_DOWN_SOUTH = register("cable_up_down_south", FeGridModBlocks.CABLE_UP_DOWN_SOUTH, CableUpDownSouthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_DOWN_EAST = register("cable_up_down_east", FeGridModBlocks.CABLE_UP_DOWN_EAST, CableUpDownEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_DOWN_WEST = register("cable_up_down_west", FeGridModBlocks.CABLE_UP_DOWN_WEST, CableUpDownWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_NORTH_SOUTH = register("cable_up_north_south", FeGridModBlocks.CABLE_UP_NORTH_SOUTH, CableUpNorthSouthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_NORTH_EAST = register("cable_up_north_east", FeGridModBlocks.CABLE_UP_NORTH_EAST, CableUpNorthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_NORTH_WEST = register("cable_up_north_west", FeGridModBlocks.CABLE_UP_NORTH_WEST, CableUpNorthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_SOUTH_EAST = register("cable_up_south_east", FeGridModBlocks.CABLE_UP_SOUTH_EAST, CableUpSouthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_SOUTH_WEST = register("cable_up_south_west", FeGridModBlocks.CABLE_UP_SOUTH_WEST, CableUpSouthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_UP_EAST_WEST = register("cable_up_east_west", FeGridModBlocks.CABLE_UP_EAST_WEST, CableUpEastWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_NORTH_SOUTH = register("cable_down_north_south", FeGridModBlocks.CABLE_DOWN_NORTH_SOUTH, CableDownNorthSouthBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_NORTH_EAST = register("cable_down_north_east", FeGridModBlocks.CABLE_DOWN_NORTH_EAST, CableDownNorthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_NORTH_WEST = register("cable_down_north_west", FeGridModBlocks.CABLE_DOWN_NORTH_WEST, CableDownNorthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_SOUTH_EAST = register("cable_down_south_east", FeGridModBlocks.CABLE_DOWN_SOUTH_EAST, CableDownSouthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_SOUTH_WEST = register("cable_down_south_west", FeGridModBlocks.CABLE_DOWN_SOUTH_WEST, CableDownSouthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_DOWN_EAST_WEST = register("cable_down_east_west", FeGridModBlocks.CABLE_DOWN_EAST_WEST, CableDownEastWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_SOUTH_EAST = register("cable_north_south_east", FeGridModBlocks.CABLE_NORTH_SOUTH_EAST, CableNorthSouthEastBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_SOUTH_WEST = register("cable_north_south_west", FeGridModBlocks.CABLE_NORTH_SOUTH_WEST, CableNorthSouthWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_NORTH_EAST_WEST = register("cable_north_east_west", FeGridModBlocks.CABLE_NORTH_EAST_WEST, CableNorthEastWestBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CABLE_SOUTH_EAST_WEST = register("cable_south_east_west", FeGridModBlocks.CABLE_SOUTH_EAST_WEST, CableSouthEastWestBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
