
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.fegrid.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.fegrid.item.WireSpoolItem;
import net.mcreator.fegrid.item.SteelIngotItem;
import net.mcreator.fegrid.item.SolarPanelCircitItem;
import net.mcreator.fegrid.item.SolarCellItem;
import net.mcreator.fegrid.item.SiliconWaferItem;
import net.mcreator.fegrid.item.SiliconNuggetItem;
import net.mcreator.fegrid.item.SiliconIngotItem;
import net.mcreator.fegrid.item.LithiumIngotItem;
import net.mcreator.fegrid.item.LithiumDustItem;
import net.mcreator.fegrid.item.IronWireItem;
import net.mcreator.fegrid.item.IronSheetItem;
import net.mcreator.fegrid.item.IronCircuitItem;
import net.mcreator.fegrid.item.GoldCircuitItem;
import net.mcreator.fegrid.item.DiamondCircitItem;
import net.mcreator.fegrid.item.CopperWireItem;
import net.mcreator.fegrid.item.CarbonItem;
import net.mcreator.fegrid.item.CapacitorItem;
import net.mcreator.fegrid.item.BauxiteDustItem;
import net.mcreator.fegrid.item.BatteryItem;
import net.mcreator.fegrid.item.BatteryGroupIItem;
import net.mcreator.fegrid.item.AluminiumIngotItem;
import net.mcreator.fegrid.item.AluminiumFrameItem;
import net.mcreator.fegrid.item.AluminaItem;
import net.mcreator.fegrid.FeGridMod;

public class FeGridModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FeGridMod.MODID);
	public static final RegistryObject<Item> ENERGY_BLOCK = block(FeGridModBlocks.ENERGY_BLOCK);
	public static final RegistryObject<Item> SOLAR_PANEL = block(FeGridModBlocks.SOLAR_PANEL);
	public static final RegistryObject<Item> SOLAR_PANEL_ON_FRAME = block(FeGridModBlocks.SOLAR_PANEL_ON_FRAME);
	public static final RegistryObject<Item> SOLAR_PANEL_FRAME = block(FeGridModBlocks.SOLAR_PANEL_FRAME);
	public static final RegistryObject<Item> SOLAR_PANEL_FRAME_WITH_POWER_CABLE = block(FeGridModBlocks.SOLAR_PANEL_FRAME_WITH_POWER_CABLE);
	public static final RegistryObject<Item> FE_TESTER = block(FeGridModBlocks.FE_TESTER);
	public static final RegistryObject<Item> SOLAR_PANEL_CIRCIT = REGISTRY.register("solar_panel_circit", () -> new SolarPanelCircitItem());
	public static final RegistryObject<Item> DIAMOND_CIRCIT = REGISTRY.register("diamond_circit", () -> new DiamondCircitItem());
	public static final RegistryObject<Item> IRON_WIRE = REGISTRY.register("iron_wire", () -> new IronWireItem());
	public static final RegistryObject<Item> ALUMINUM_SHEET = REGISTRY.register("aluminum_sheet", () -> new IronSheetItem());
	public static final RegistryObject<Item> CAPACITOR = REGISTRY.register("capacitor", () -> new CapacitorItem());
	public static final RegistryObject<Item> EXTRUDER = block(FeGridModBlocks.EXTRUDER);
	public static final RegistryObject<Item> WIRE_SPOOL = REGISTRY.register("wire_spool", () -> new WireSpoolItem());
	public static final RegistryObject<Item> GOLD_CIRCUIT = REGISTRY.register("gold_circuit", () -> new GoldCircuitItem());
	public static final RegistryObject<Item> IRON_CIRCUIT = REGISTRY.register("iron_circuit", () -> new IronCircuitItem());
	public static final RegistryObject<Item> CABLE = block(FeGridModBlocks.CABLE);
	public static final RegistryObject<Item> COPPER_WIRE = REGISTRY.register("copper_wire", () -> new CopperWireItem());
	public static final RegistryObject<Item> HALF_A_MILLION_STORAGE_BLOCK = block(FeGridModBlocks.HALF_A_MILLION_STORAGE_BLOCK);
	public static final RegistryObject<Item> BAUXITE_DUST = REGISTRY.register("bauxite_dust", () -> new BauxiteDustItem());
	public static final RegistryObject<Item> BAUXITE_ORE = block(FeGridModBlocks.BAUXITE_ORE);
	public static final RegistryObject<Item> BAUXITE_BLOCK = block(FeGridModBlocks.BAUXITE_BLOCK);
	public static final RegistryObject<Item> ALUMINIUM_INGOT = REGISTRY.register("aluminium_ingot", () -> new AluminiumIngotItem());
	public static final RegistryObject<Item> ALUMINIUM_BLOCK = block(FeGridModBlocks.ALUMINIUM_BLOCK);
	public static final RegistryObject<Item> ALUMINIUM_FRAME = REGISTRY.register("aluminium_frame", () -> new AluminiumFrameItem());
	public static final RegistryObject<Item> ALUMINIUM_PROCESSOR = block(FeGridModBlocks.ALUMINIUM_PROCESSOR);
	public static final RegistryObject<Item> ALUMINA = REGISTRY.register("alumina", () -> new AluminaItem());
	public static final RegistryObject<Item> QUARTER_OF_A_MILLION_STORAGE_BLOCK = block(FeGridModBlocks.QUARTER_OF_A_MILLION_STORAGE_BLOCK);
	public static final RegistryObject<Item> SMELTER = block(FeGridModBlocks.SMELTER);
	public static final RegistryObject<Item> ONE_MILLION_STORAGE_UNIT = block(FeGridModBlocks.ONE_MILLION_STORAGE_UNIT);
	public static final RegistryObject<Item> SOLAR_CELL = REGISTRY.register("solar_cell", () -> new SolarCellItem());
	public static final RegistryObject<Item> SILICON_WAFER = REGISTRY.register("silicon_wafer", () -> new SiliconWaferItem());
	public static final RegistryObject<Item> SILICA_SAND = block(FeGridModBlocks.SILICA_SAND);
	public static final RegistryObject<Item> SILICON_NUGGET = REGISTRY.register("silicon_nugget", () -> new SiliconNuggetItem());
	public static final RegistryObject<Item> SILICON_INGOT = REGISTRY.register("silicon_ingot", () -> new SiliconIngotItem());
	public static final RegistryObject<Item> GRANITE = block(FeGridModBlocks.GRANITE);
	public static final RegistryObject<Item> LITHIUM_DUST = REGISTRY.register("lithium_dust", () -> new LithiumDustItem());
	public static final RegistryObject<Item> LITHIUM_INGOT = REGISTRY.register("lithium_ingot", () -> new LithiumIngotItem());
	public static final RegistryObject<Item> LITHIUM_BLOCK = block(FeGridModBlocks.LITHIUM_BLOCK);
	public static final RegistryObject<Item> CARBON = REGISTRY.register("carbon", () -> new CarbonItem());
	public static final RegistryObject<Item> STEEL_INGOT = REGISTRY.register("steel_ingot", () -> new SteelIngotItem());
	public static final RegistryObject<Item> STEEL_BLOCK = block(FeGridModBlocks.STEEL_BLOCK);
	public static final RegistryObject<Item> BATTERY = REGISTRY.register("battery", () -> new BatteryItem());
	public static final RegistryObject<Item> BATTERY_GROUP_I = REGISTRY.register("battery_group_i", () -> new BatteryGroupIItem());
	public static final RegistryObject<Item> CABLE_NORTH = block(FeGridModBlocks.CABLE_NORTH);
	public static final RegistryObject<Item> CABLE_SOUTH = block(FeGridModBlocks.CABLE_SOUTH);
	public static final RegistryObject<Item> CABLE_EAST = block(FeGridModBlocks.CABLE_EAST);
	public static final RegistryObject<Item> CABLE_WEST = block(FeGridModBlocks.CABLE_WEST);
	public static final RegistryObject<Item> CABLE_UP = block(FeGridModBlocks.CABLE_UP);
	public static final RegistryObject<Item> CABLE_DOWN = block(FeGridModBlocks.CABLE_DOWN);
	public static final RegistryObject<Item> CABLE_EAST_WEST = block(FeGridModBlocks.CABLE_EAST_WEST);
	public static final RegistryObject<Item> CABLE_SOUTH_NORTH = block(FeGridModBlocks.CABLE_SOUTH_NORTH);
	public static final RegistryObject<Item> CABLE_UP_DOWN = block(FeGridModBlocks.CABLE_UP_DOWN);
	public static final RegistryObject<Item> CABLE_NORTH_DOWN = block(FeGridModBlocks.CABLE_NORTH_DOWN);
	public static final RegistryObject<Item> CABLE_NORTH_UP = block(FeGridModBlocks.CABLE_NORTH_UP);
	public static final RegistryObject<Item> CABLE_NORTH_EAST = block(FeGridModBlocks.CABLE_NORTH_EAST);
	public static final RegistryObject<Item> CABLE_NORTH_WEST = block(FeGridModBlocks.CABLE_NORTH_WEST);
	public static final RegistryObject<Item> CABLE_SOUTH_DOWN = block(FeGridModBlocks.CABLE_SOUTH_DOWN);
	public static final RegistryObject<Item> CABLE_SOUTH_UP = block(FeGridModBlocks.CABLE_SOUTH_UP);
	public static final RegistryObject<Item> CABLE_SOUTH_EAST = block(FeGridModBlocks.CABLE_SOUTH_EAST);
	public static final RegistryObject<Item> CABLE_SOUTH_WEST = block(FeGridModBlocks.CABLE_SOUTH_WEST);
	public static final RegistryObject<Item> CABLE_EAST_DOWN = block(FeGridModBlocks.CABLE_EAST_DOWN);
	public static final RegistryObject<Item> CABLE_EAST_UP = block(FeGridModBlocks.CABLE_EAST_UP);
	public static final RegistryObject<Item> CABLE_WEST_DOWN = block(FeGridModBlocks.CABLE_WEST_DOWN);
	public static final RegistryObject<Item> CABLE_WEST_UP = block(FeGridModBlocks.CABLE_WEST_UP);
	public static final RegistryObject<Item> CABLE_UP_DOWN_NORTH = block(FeGridModBlocks.CABLE_UP_DOWN_NORTH);
	public static final RegistryObject<Item> CABLE_UP_DOWN_SOUTH = block(FeGridModBlocks.CABLE_UP_DOWN_SOUTH);
	public static final RegistryObject<Item> CABLE_UP_DOWN_EAST = block(FeGridModBlocks.CABLE_UP_DOWN_EAST);
	public static final RegistryObject<Item> CABLE_UP_DOWN_WEST = block(FeGridModBlocks.CABLE_UP_DOWN_WEST);
	public static final RegistryObject<Item> CABLE_UP_NORTH_SOUTH = block(FeGridModBlocks.CABLE_UP_NORTH_SOUTH);
	public static final RegistryObject<Item> CABLE_UP_NORTH_EAST = block(FeGridModBlocks.CABLE_UP_NORTH_EAST);
	public static final RegistryObject<Item> CABLE_UP_NORTH_WEST = block(FeGridModBlocks.CABLE_UP_NORTH_WEST);
	public static final RegistryObject<Item> CABLE_UP_SOUTH_EAST = block(FeGridModBlocks.CABLE_UP_SOUTH_EAST);
	public static final RegistryObject<Item> CABLE_UP_SOUTH_WEST = block(FeGridModBlocks.CABLE_UP_SOUTH_WEST);
	public static final RegistryObject<Item> CABLE_UP_EAST_WEST = block(FeGridModBlocks.CABLE_UP_EAST_WEST);
	public static final RegistryObject<Item> CABLE_DOWN_NORTH_SOUTH = block(FeGridModBlocks.CABLE_DOWN_NORTH_SOUTH);
	public static final RegistryObject<Item> CABLE_DOWN_NORTH_EAST = block(FeGridModBlocks.CABLE_DOWN_NORTH_EAST);
	public static final RegistryObject<Item> CABLE_DOWN_NORTH_WEST = block(FeGridModBlocks.CABLE_DOWN_NORTH_WEST);
	public static final RegistryObject<Item> CABLE_DOWN_SOUTH_EAST = block(FeGridModBlocks.CABLE_DOWN_SOUTH_EAST);
	public static final RegistryObject<Item> CABLE_DOWN_SOUTH_WEST = block(FeGridModBlocks.CABLE_DOWN_SOUTH_WEST);
	public static final RegistryObject<Item> CABLE_DOWN_EAST_WEST = block(FeGridModBlocks.CABLE_DOWN_EAST_WEST);
	public static final RegistryObject<Item> CABLE_NORTH_SOUTH_EAST = block(FeGridModBlocks.CABLE_NORTH_SOUTH_EAST);
	public static final RegistryObject<Item> CABLE_NORTH_SOUTH_WEST = block(FeGridModBlocks.CABLE_NORTH_SOUTH_WEST);
	public static final RegistryObject<Item> CABLE_NORTH_EAST_WEST = block(FeGridModBlocks.CABLE_NORTH_EAST_WEST);
	public static final RegistryObject<Item> CABLE_SOUTH_EAST_WEST = block(FeGridModBlocks.CABLE_SOUTH_EAST_WEST);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
