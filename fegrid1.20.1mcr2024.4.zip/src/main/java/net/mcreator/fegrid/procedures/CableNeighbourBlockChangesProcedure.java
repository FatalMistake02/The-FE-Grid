package net.mcreator.fegrid.procedures;

import net.minecraft.world.level.LevelAccessor;

public class CableNeighbourBlockChangesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		CableAddToWorldProcedure.execute(world, x, y, z);
	}
}
