package net.mcreator.thefegrid.procedures;

public class SolarPanelOnBlockRightClickedProcedure {
	public static void execute() {
	}
}
